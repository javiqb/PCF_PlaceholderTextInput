/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./PlaceholderText/index.ts"
/*!**********************************!*\
  !*** ./PlaceholderText/index.ts ***!
  \**********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   PlaceholderText: () => (/* binding */ PlaceholderText)\n/* harmony export */ });\nclass PlaceholderText {\n  constructor() {\n    this.currentValue = \"\";\n    this.isMultiline = false;\n  }\n  init(_context, notifyOutputChanged, _state, container) {\n    this.container = container;\n    this.notifyOutputChanged = notifyOutputChanged;\n    // Wrapper that draws the field background/border (chrome)\n    this.host = document.createElement(\"div\");\n    this.host.className = \"evidi-field-host\";\n    // Single line input\n    this.input = document.createElement(\"input\");\n    this.input.type = \"text\";\n    this.input.className = \"evidi-placeholder-input\";\n    this.input.addEventListener(\"input\", () => {\n      this.currentValue = this.input.value;\n      this.notifyOutputChanged();\n    });\n    // Multi line textarea\n    this.textarea = document.createElement(\"textarea\");\n    this.textarea.className = \"evidi-placeholder-textarea\";\n    this.textarea.addEventListener(\"input\", () => {\n      this.currentValue = this.textarea.value;\n      this.notifyOutputChanged();\n    });\n    // Default render\n    this.host.appendChild(this.input);\n    this.container.appendChild(this.host);\n  }\n  updateView(context) {\n    var _a, _b, _c, _d;\n    var value = (_a = context.parameters.value.raw) !== null && _a !== void 0 ? _a : \"\";\n    // If you added the \"multiline\" input (TwoOptions) in manifest:\n    var shouldBeMultiline = ((_b = context.parameters.multiline) === null || _b === void 0 ? void 0 : _b.raw) === true;\n    // Swap inside host\n    if (shouldBeMultiline !== this.isMultiline) {\n      this.isMultiline = shouldBeMultiline;\n      this.host.replaceChildren(this.isMultiline ? this.textarea : this.input);\n    }\n    // Placeholder\n    var placeholder = (_c = context.parameters.placeholder.raw) !== null && _c !== void 0 ? _c : \"\";\n    if (this.isMultiline) this.textarea.placeholder = placeholder;else this.input.placeholder = placeholder;\n    // Rows for textarea\n    if (this.isMultiline) {\n      var rows = (_d = context.parameters.rows.raw) !== null && _d !== void 0 ? _d : 3;\n      this.textarea.rows = Math.max(1, rows);\n    }\n    // Value + disabled\n    this.currentValue = value;\n    if (this.isMultiline) {\n      if (this.textarea.value !== value) this.textarea.value = value;\n      this.textarea.disabled = context.mode.isControlDisabled;\n    } else {\n      if (this.input.value !== value) this.input.value = value;\n      this.input.disabled = context.mode.isControlDisabled;\n    }\n  }\n  getOutputs() {\n    return {\n      value: this.currentValue\n    };\n  }\n  destroy() {\n    var _a, _b, _c;\n    (_a = this.input) === null || _a === void 0 ? void 0 : _a.remove();\n    (_b = this.textarea) === null || _b === void 0 ? void 0 : _b.remove();\n    (_c = this.host) === null || _c === void 0 ? void 0 : _c.remove();\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./PlaceholderText/index.ts?\n}");

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./PlaceholderText/index.ts"](0,__webpack_exports__,__webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('Evidi.PlaceholderText', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.PlaceholderText);
} else {
	var Evidi = Evidi || {};
	Evidi.PlaceholderText = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.PlaceholderText;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}